<?php
$day = htmlspecialchars($_POST['date']);
$groupId = htmlspecialchars($_POST['group']); 


$link = mysqli_connect("127.0.0.1", "bpt", "13579!Aa", "bpt");
$query = "SET CHARACTER SET 'utf8'";
mysqli_query($link, $query);

if (!empty($day)){
	
	$i = 0;
	$query = "select `teacherLoadId`, `number`, `type` from `shedule` where `teacherLoadId` IN (select `id` from `teacherLoad` where `groupId` ='" . $groupId . "') and `date` = '" . $day . "' ORDER BY `number`";
	$result = mysqli_query($link, $query);
	while ($row = mysqli_fetch_array($result)) {
		$arrLoads[$i][0] = $row['teacherLoadId'];
		$arrLoads[$i][1] = $row['number'];
		$arrLoads[$i][3] = $row['type'];
		$i++;
		}
	mysqli_free_result($result);
	
	if (count($arrLoads) == 0){
		echo "Нет занятий";
		}
	else {		
		for ($j = 0; $j <= count($arrLoads); $j++){
			$query = "SELECT shortName FROM discipline WHERE id IN (SELECT disciplineId FROM teacherLoad where id = ".$arrLoads[$j][0] . ")";
			$result = mysqli_query($link, $query);			
			while ($row = mysqli_fetch_array($result)) {
				$arrLoads[$j][2] = $row['shortName'];
				}
			mysqli_free_result($result);	
				
			}
				
		foreach ($arrLoads as $v1){
			echo "<br>" . $v1["1"] . ") " . $v1["2"] . " " . $v1["3"];
			}
		}
	} 
	
else {
	echo "Не указана дата";
	};

unset($day);
unset($group);
mysqli_close($link);
?>
