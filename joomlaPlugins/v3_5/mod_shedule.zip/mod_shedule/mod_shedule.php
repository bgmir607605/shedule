<?php 

defined( '_JEXEC' ) or die( 'Restricted access' ); // требование безопасности

// получаем ссылку на экземпляр класса JDocument
$doc = & JFactory::getDocument();
// добавляем внешний JavaScript файл, который располагается в каталоге [корень_сайта]/modules/mod_mymodule/js/tooltip.js
$doc->addScript(JURI::root(true) . "/modules/mod_shedule/jquery-3.1.1.min.js");
$doc->addScript(JURI::root(true) . "/modules/mod_shedule/shedule.js");

$link = mysqli_connect("127.0.0.1", "bpt", "13579!Aa", "bpt");

if (!$link) {
    echo "Ошибка: Невозможно установить соединение с MySQL." . PHP_EOL;
    echo "Код ошибки errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Текст ошибки error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}

$query = "SET CHARACTER SET 'utf8'";
mysqli_query($link, $query);

$query = "SELECT id, name FROM groups";

echo 'Дата:';
echo '<input type="date" id="date" onchange="mytest()">';

if ($result = mysqli_query($link, $query)) {
	echo "Группа";
	echo '<select id="selectGroup" onchange="mytest()">';
    while ($row = mysqli_fetch_assoc($result)) {
			echo '<option value="'.$row["id"].'">'.$row["name"].'</option>';
    }
	echo "</select>";
	echo '<div id="sheduleContent"></div>';
    mysqli_free_result($result);
}

mysqli_close($link);

?>
