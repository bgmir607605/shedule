function mytest () {
	jQuery.ajax({
		type: "POST",
		url: "/modules/mod_shedule/ajax.php",
		dataType:"text",
		data: 'group='+jQuery("#selectGroup option:selected").val() + '&date=' + jQuery("#date").val(),
		error: function(){
			alert('error');
		},
		success: function(response){
			jQuery("#sheduleContent").html(response);
		}
	});
	
}


