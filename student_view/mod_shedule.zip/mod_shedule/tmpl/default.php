<?php 
// No direct access
defined('_JEXEC') or die; ?>
<?php echo $hello; ?>