<?php defined( '_JEXEC' ) or die( 'Restricted access' ); // требование безопасности
    //echo 'Hello, world!' ;
    $hello = 'hi, teacher!;
?>